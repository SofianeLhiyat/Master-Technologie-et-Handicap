package com.example.poubelleconnecte;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private static final String BASE_URL = "http://10.142.242.206:5000/";
    private static final String TAG = "MainActivity";
    private TextView predictionResult;
    private Button getPredictionButton;
    private Call<PredictionResponse> currentCall;
    private List<String> class_names = Arrays.asList("carton", "verre", "alluminium", "papier", "plastique", "rien");
    private Retrofit retrofit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getPredictionButton = findViewById(R.id.getPredictionButton);
        predictionResult = findViewById(R.id.predictionResult);

        setupRetrofit();

        getPredictionButton.setOnClickListener(v -> fetchPrediction());
    }

    private void setupRetrofit() {
        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
    }

    private void fetchPrediction() {
        getPredictionButton.setEnabled(false);
        predictionResult.setText("Analyse en cours...");

        ServerApi serverApi = retrofit.create(ServerApi.class);
        currentCall = serverApi.getPrediction();  // Pas besoin de cast ici maintenant

        currentCall.enqueue(new Callback<PredictionResponse>() {
            @Override
            public void onResponse(Call<PredictionResponse> call, Response<PredictionResponse> response) {
                getPredictionButton.setEnabled(true);

                if (call.isCanceled()) return;

                if (response.isSuccessful() && response.body() != null) {
                    String predictedClass = response.body().getClassName();
                    String capitalizedClass = predictedClass.substring(0, 1).toUpperCase() + predictedClass.substring(1);
                    showValidationDialog(predictedClass, capitalizedClass);
                } else {
                    handleError("Erreur d'analyse");
                }
            }

            @Override
            public void onFailure(Call<PredictionResponse> call, Throwable t) {
                getPredictionButton.setEnabled(true);

                if (call.isCanceled()) return;
                handleError("Erreur de connexion : " + t.getMessage());
            }
        });
    }

    private void handleError(String message) {
        Log.e(TAG, message);
        predictionResult.setText("Erreur");
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void showValidationDialog(final String originalClass, String capitalizedClass) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Validation de la détection");
        builder.setMessage("Le matériau détecté est : " + capitalizedClass + "\nEst-ce correct ?");

        builder.setPositiveButton("Oui", (dialog, which) -> {
            sendFeedback(true, null);
            predictionResult.setText("Matériau détecté : " + capitalizedClass);
            dialog.dismiss();
        });

        builder.setNegativeButton("Non", (dialog, which) -> {
            showClassSelectionDialog(originalClass);
            dialog.dismiss();
        });

        builder.show();
    }

    private void showClassSelectionDialog(String originalClass) {
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Sélectionnez le bon matériau");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20, 20, 20, 20);

        for (String className : class_names) {
            Button button = new Button(this);
            String capitalizedClass = className.substring(0, 1).toUpperCase() + className.substring(1);
            button.setText(capitalizedClass);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(0, 10, 0, 10);
            button.setLayoutParams(params);

            button.setOnClickListener(v -> {
                sendFeedback(false, className);
                predictionResult.setText("Matériau corrigé : " + capitalizedClass);
                alertDialog.dismiss(); 
                getPredictionButton.setEnabled(true);
            });

            layout.addView(button);
        }

        alertDialog.setView(layout);
        alertDialog.show();
    }

    private void sendFeedback(boolean isCorrect, String correctedClass) {
        ServerApi serverApi = retrofit.create(ServerApi.class);
        FeedbackRequest feedback = new FeedbackRequest(isCorrect, correctedClass);

        Call<FeedbackResponse> feedbackCall = serverApi.sendFeedback(feedback);
        feedbackCall.enqueue(new Callback<FeedbackResponse>() {
            @Override
            public void onResponse(Call<FeedbackResponse> call, Response<FeedbackResponse> response) {
                if (response.isSuccessful()) {
                    Log.d(TAG, "Feedback envoyé avec succès");
                } else {
                    Log.e(TAG, "Erreur lors de l'envoi du feedback");
                }
            }

            @Override
            public void onFailure(Call<FeedbackResponse> call, Throwable t) {
                Log.e(TAG, "Échec de l'envoi du feedback", t);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (currentCall != null) {
            currentCall.cancel();
        }
    }
}