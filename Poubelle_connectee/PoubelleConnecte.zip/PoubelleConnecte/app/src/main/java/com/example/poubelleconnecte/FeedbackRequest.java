package com.example.poubelleconnecte;

public class FeedbackRequest {
    private boolean is_correct;
    private String corrected_class;

    public FeedbackRequest(boolean is_correct, String corrected_class) {
        this.is_correct = is_correct;
        this.corrected_class = corrected_class;
    }
}