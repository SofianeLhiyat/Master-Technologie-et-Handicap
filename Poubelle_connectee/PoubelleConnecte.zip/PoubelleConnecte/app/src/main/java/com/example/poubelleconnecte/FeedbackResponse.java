package com.example.poubelleconnecte;

public class FeedbackResponse {
    private String message;
    private String error;

    public String getMessage() {
        return message;
    }

    public String getError() {
        return error;
    }
}