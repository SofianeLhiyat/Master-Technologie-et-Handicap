package com.example.poubelleconnecte;

import com.google.gson.annotations.SerializedName;

public class PredictionResponse {
    @SerializedName("class")
    private String className;

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
}